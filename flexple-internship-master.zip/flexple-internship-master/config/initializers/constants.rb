SUCCESS_MESSAGE = 'Successfully completed!'
ERROR_MESSAGE = 'Oops! Something went wrong.'
