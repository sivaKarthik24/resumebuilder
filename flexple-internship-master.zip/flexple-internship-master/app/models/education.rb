class Education < ApplicationRecord
    belongs_to :profile
end
