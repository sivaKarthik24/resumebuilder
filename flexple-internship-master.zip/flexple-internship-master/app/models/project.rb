class Project < ApplicationRecord
    belongs_to :experience
  
    
  end